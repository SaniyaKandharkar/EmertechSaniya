const express = require('express')
const mongoose = require('mongoose')
const url = 'mongodb://localhost/StudentInfo'
const app = express()

mongoose.connect(url, {useNewUrlParser:true,
    useUnifiedTopology: true})
const conn = mongoose.connection

conn.on('open', function(){
    console.log('Connected')
}) 

app.use(express.json())
app.use(express.urlencoded({ extended: true }));


const studentRouter = require('./routes/students')
app.use('/students', studentRouter)


app.listen(3000, function(){
    console.log('Server Running')
})