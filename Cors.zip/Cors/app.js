const { request, response } = require('express');
const express = require('express');

const app = express();
app.set(request,response,next => {
     response.header("Access-Control-Allow-Origin","*");
     response.header("Access-Control-Allow-Headers","Origin, X-Requested-With,Content-Type,Accept");
     next();
});
app.get("/",(request,response) =>{
    response.send("Welcome to Emertech! Have a nice day!");
});
app.listen(3000 ,() => {
    console.log("Server running");
});