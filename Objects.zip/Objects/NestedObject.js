var car = {
    name: "Audi",
    number: 123,
    color: "Black",
    model: {
        modelNo : "Q7"
    }
};

console.log(car.model.modelNo);

car.model.newModelNo = "A6";

console.log(car.model["newModelNo"]);