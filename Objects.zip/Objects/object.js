var person1 = {
    name: "Saniya",
    age: 21,
    rollNo: 26,
    updateAge: function(){
        return ++person1.age; 
    }
}

var person2 = {
    name: "ABC",
    age: 22,
    rollNo: 33,
    updateAge: function(){
        return ++person2.age; 
    }
}
console.log(person1.age)
console.log(person2.age)
person1.updateAge();
person2.updateAge();