const results = [
    { name: 'Saniya', marks: 100},
    { name: 'Ketaki', marks: 90},
    { name: 'Nilesh', marks: 80},
    { name: 'Atharva', marks: 70}
]

const filteredResults = results.filter((results) => {
    return results.marks >=75
}) 

console.log(filteredResults)