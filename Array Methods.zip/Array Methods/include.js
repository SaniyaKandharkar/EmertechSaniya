const items = [1, 2, 3, 4, 5]

const includesTwo = items.includes(7) 

console.log(includesTwo)