const results = [
    { name: 'Saniya', marks: 100},
    { name: 'Ketaki', marks: 90},
    { name: 'Nilesh', marks: 80},
    { name: 'Atharva', marks: 70}
]

const names = results.map((results) => {
    return results.marks 
}) 

console.log(names)