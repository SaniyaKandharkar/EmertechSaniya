const results = [
    { name: 'Saniya', marks: 100},
    { name: 'Atharva', marks: 70},
    { name: 'Ketaki', marks: 90},
    { name: 'Nilesh', marks: 80}
]

const total = results.every((results, currentTotal) => {
    return results.marks + currentTotal
},0) 

console.log(total)