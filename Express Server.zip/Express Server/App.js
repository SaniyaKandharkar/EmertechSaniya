const express = require('express');
const port = 3000;

const server = express();
server.get('/', function(req, res){
    res.send('Hello Node!')
})

server.get('/emertech', function(req, res){
    res.send('Welcome back to Emertech')
})


server.listen(port, function(error){
    if(error){
        console.log('Something went wrong', error)
    } else{
        console.log('Server is listening on port '+port)
    }
})